define(function(require,exports,module){
	var $=require('jquery');
	var dataHandler=function(){
	};
	module.exports=dataHandler;
	dataHandler.prototype={

	};
});